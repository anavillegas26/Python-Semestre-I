# Nombres de los Integrantes: Benjamin Alocilla y Ana Villegas

# primero asignamos el valor a nuestras variables
numero_1 = 500
numero_2 = 556

# luego usamos un while y un != para indicar que continue hasta que sea igual a 800
while numero_1 != 800:
    print(numero_1)
    print(numero_2)
    numero_1 = numero_1 + 10
    numero_2 = numero_2 - 2


print(numero_1)
